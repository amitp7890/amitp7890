from helloworld.world import world as worldmod_tester

def test_get_msg():
    # when
    result = worldmod_tester.get_msg()

    # then
    assert result == 'world'

def test_do_min():
    # when
    result = worldmod_tester.do_min()

    # then
    assert result == 10

def test_do_max():
    # when
    result = worldmod_tester.do_max()

    # then
    assert result == 60

def test_say(capsys):
    # when
    worldmod_tester.say()
    result = capsys.readouterr()

    # then
    assert 'world' in result.out

def test_run(capsys):
    # when
    worldmod_tester.run()
    result = capsys.readouterr()

    # then
    assert 'world' in result.out

#def test_say():
#    # when
#    result = worldmod_tester.say()
#
#    # then
#    assert result == 'world'

#def test_run():
#    # when
#    result = worldmod_tester.run()
#
#    # then
#    assert result == 'world'
