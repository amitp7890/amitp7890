import pytest
from helloworld.world.helpers import calc_min, calc_max

#@pytest.mark.skip
def test_min():
    # given
    values = (2, 3, 1, 4, 6)

    # when
    val = calc_min(values)

    # then
    assert val == 1

def test_max():
    # given
    values = (2, 3, 1, 4, 6)

    # when
    val = calc_max(values)

    # then
    assert val == 6
