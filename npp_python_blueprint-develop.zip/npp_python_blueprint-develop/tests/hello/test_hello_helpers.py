import pytest
from helloworld.hello.helpers import calc_addition, calc_subtraction, calc_multiply

def test_calc_addition():
    # given
    val1 = 40
    val2 = 19

    # when
    result = calc_addition(val1, val2)

    # then
    assert result == 59

def test_calc_subtraction():
    # given
    val1 = 40
    val2 = 19

    # when
    result = calc_subtraction(val1, val2)

    # then
    assert result == 21

def test_calc_multiply():
    # given
    val1 = 40
    val2 = 19

    # when
    result = calc_multiply(val1, val2)

    # then
    assert result == 760
