from helloworld.hello import hello as hellomod_tester

def test_get_msg():
    # when
    result = hellomod_tester.get_msg()

    # then
    assert result == 'hello'

def test_do_add():
    # when
    result = hellomod_tester.do_add()

    # then
    assert result == 30

def test_do_subtract():
    # when
    result = hellomod_tester.do_subtract()

    # then
    assert result == -10

def test_do_multiply():
    # when
    result = hellomod_tester.do_multiply()

    # then
    assert result == 3000

def test_say(capsys):
    # when
    hellomod_tester.say()
    result = capsys.readouterr()

    # then
    assert 'hello' in result.out

def test_run(capsys):
    # when
    hellomod_tester.run()
    result = capsys.readouterr()

    # then
    assert 'hello' in result.out

#def test_say():
#    # when
#    result = hellomod_tester.say()
#
#    # then
#    assert result == 'hello'

#def test_run():
#    # when
#    result = hellomod_tester.run()
#
#    # then
#    assert result == 'hello'
