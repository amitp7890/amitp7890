from helloworld.runner import main as helloworldpkg_tester

def test_runner_main(capsys):
    # when
    helloworldpkg_tester()
    result = capsys.readouterr()

    # then
    assert 'hello world' in result.out
