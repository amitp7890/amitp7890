from helloworld.hello import hello as hellomod
from helloworld.world import world as worldmod

def main():
    print( hellomod.get_msg() + ' ' +  worldmod.get_msg() + '...')

    hellomod.run()
    worldmod.run()

if __name__ == "__main__":
    print('INFO:  PACKAGE: \'' + str(__package__) + '\'')
    print('INFO:  NAME: \'' + str(__name__) + '\'')

    main()

