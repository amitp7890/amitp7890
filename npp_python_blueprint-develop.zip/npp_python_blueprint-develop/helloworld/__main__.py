from helloworld import runner

if __name__ == "__main__":
    print('INFO:  PACKAGE: \'' + str(__package__) + '\'')
    print('INFO:  NAME: \'' + str(__name__) + '\'')
    runner.main()

