from helloworld.world import helpers as comparer

def get_msg():
    return 'world'

def do_min():
    return comparer.calc_min([10,20,30,40,50,60])

def do_max():
    return comparer.calc_max([10,20,30,40,50,60])

def say():
    print('SAY: \'' + get_msg() + '\'')

def run():
    say()

    print('MIN: \'' + str(do_min()) + '\'')
    print('MAX: \'' + str(do_max()) + '\'')

if __name__ == "__main__":
    print('INFO:  PACKAGE: \'' + str(__package__) + '\'')
    print('INFO:  NAME: \'' + str(__name__) + '\'')

    run()
