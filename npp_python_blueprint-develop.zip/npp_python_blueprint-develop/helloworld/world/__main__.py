from helloworld.world import world as worldmod

if __name__ == "__main__":
    print('INFO:  PACKAGE: \'' + str(__package__) + '\'')
    print('INFO:  NAME: \'' + str(__name__) + '\'')

    worldmod.run()
