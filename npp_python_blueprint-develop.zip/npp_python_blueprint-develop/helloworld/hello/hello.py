from helloworld.hello import helpers as solver

def get_msg():
    return 'hello'

def do_add():
    return solver.calc_addition(10,20)

def do_subtract():
    return solver.calc_subtraction(30,40)

def do_multiply():
    return solver.calc_multiply(50,60)

def say():
    print('SAY: \'' + get_msg() + '\'')

def run():
    say()

    print('ADD: \'' + str(do_add()) + '\'')
    print('SUB: \'' + str(do_subtract()) + '\'')
    print('MUL: \'' + str(do_multiply()) + '\'')

if __name__ == "__main__":
    print('INFO:  PACKAGE: \'' + str(__package__) + '\'')
    print('INFO:  NAME: \'' + str(__name__) + '\'')

    run()
