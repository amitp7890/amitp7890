def calc_addition(a, b):
    return a + b
 
def calc_multiply(a, b):
    return a * b
     
def calc_subtraction(a, b):
    return a - b
