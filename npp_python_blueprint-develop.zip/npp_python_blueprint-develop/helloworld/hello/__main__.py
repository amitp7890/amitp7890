from helloworld.hello import hello as hellomod

if __name__ == "__main__":
    print('INFO:  PACKAGE: \'' + str(__package__) + '\'')
    print('INFO:  NAME: \'' + str(__name__) + '\'')

    hellomod.run()
