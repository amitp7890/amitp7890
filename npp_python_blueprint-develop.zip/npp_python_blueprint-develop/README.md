# Blueprint For Python Projects

## Project Makefile

```shell
$ make help    # Makefile usage for POD
$ make venv    # Create Python Virtual Environment
$ make test    # Test the POD Application
$ make dist    # Create the POD Ditribution
$ make deploy  # Create the POD Deployment
$ make run     # Run the POD Application
$ make clean   # Clean un-tracked POD project files
```

## References

### Python Directory Structure
- <https://docs.python-guide.org/writing/structure/>
- <https://github.com/navdeep-G/samplemod>
- <https://kenreitz.org/essays/2013/01/27/repository-structure-and-python>
- <https://realpython.com/python-application-layouts/>
- <https://dev.to/codemouse92/dead-simple-python-project-structure-and-imports-38c6>
- <https://towardsdatascience.com/ultimate-setup-for-your-next-python-project-179bda8a7c2c>
- <https://github.com/MartinHeinz/python-project-blueprint>
- <https://github.com/PyCQA>
- <https://www.python.org/dev/peps/pep-0008/>

### Python Testing
- <https://docs.pytest.org/en/latest/contents.html>
- <https://realpython.com/python-testing/>
- <https://realpython.com/pytest-python-testing/>
- <https://github.com/pluralsight/intro-to-pytest>
- <https://github.com/poldrack/pytest_tutorial>
- <https://smarie.github.io/pytest-patterns/>
- <https://github.com/smarie/pytest-patterns>
- <https://github.com/ptracesecurity/pytest-example>

### Python Executable
- <https://github.com/pantsbuild/pex>
- <https://pex.readthedocs.io/en/v2.1.43/buildingpex.html>
- <https://medium.com/ovni/pex-python-executables-c0ea39cee7f1>
- <https://github.com/shearn89/pex-demo>
- <https://github.com/shearn89/pex-demo/blob/main/TUTORIAL.md>
- <https://gist.github.com/simeonf/062af826e79259bc7686>

### Python Miscellaneous
- <https://github.com/pantsbuild>
- <https://www.pantsbuild.org/>
- <https://tox.readthedocs.io/en/latest/>
- <https://pypi.org/project/toml/>
- <https://en.wikipedia.org/wiki/TOML>

